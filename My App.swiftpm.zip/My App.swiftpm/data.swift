import Foundation
import SwiftUI

struct partie1 {
    var capital: Int
    var nb_jours: Int 
    var pourcentage: Int 
    lazy var taux_annuel = pourcentage/100
    lazy var taux_periodique = taux_annuel/365
    lazy var interet = capital * (taux_periodique * nb_jours)
    lazy var valeur_acquise =  capital + interet
}

let partie1infos = partie1(capital: <#T##Int#>, nb_jours: <#T##Int#>, pourcentage: <#T##Int#>, taux_annuel: <#T##Int?#>, taux_periodique: <#T##Int?#>, interet: <#T##Int?#>, valeur_acquise: <#T##Int?#>)
