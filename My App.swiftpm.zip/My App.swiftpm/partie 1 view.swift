import SwiftUI

struct ContentView: View {
    var partie1infos = partie1(capital: 8000, nb_jours: 72, pourcentage: 6)
    var body: some View {
        VStack {
            Image(systemName: "dollarsign.square.fill")
                .imageScale(.large)
            Text("Les intérêts gagnés après 72 jours sont:")
            partie1infos.interet
            Text("La valeur acquise après 72 jours est:")
            partie1infos.valeur_acquise
        }
    }
}
