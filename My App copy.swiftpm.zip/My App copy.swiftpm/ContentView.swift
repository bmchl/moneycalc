//
//  ContentView.swift
//  MyProject
//
//  Designed in DetailsPro
//  Copyright © (My Organization). All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
		VStack {
			ScrollView(.vertical, showsIndicators: true) {
				VStack {
					VStack(spacing: 0) {
						Text("partie 1")
							.font(Font.system(.largeTitle, design: .monospaced).weight(.semibold))
							.frame(maxWidth: .infinity, alignment: .leading)
							.clipped()
							.padding(.leading)
							.padding(.top, 90)
							.padding(.bottom)
					}
					.frame(maxWidth: .infinity)
					.clipped()
					Divider()
					VStack {
						Image(systemName: "dollarsign.square.fill")
							.imageScale(.large)
							.padding()
						Text("Les intérêts gagnés après 72 jours sont:")
							.padding()
						Text("La valeur acquise après 72 jours est:")
							.padding()
					}
					.padding(.vertical, 211)
				}
			}
			HStack(spacing: 10) {
				VStack(spacing: 4) {
					Image(systemName: "1.circle.fill")
						.imageScale(.large)
						.frame(maxHeight: .infinity)
						.clipped()
					Text("partie 1")
						.font(.caption2)
				}
				.foregroundColor(Color.blue)
				.frame(maxWidth: .infinity, alignment: .center)
				.clipped()
				VStack(spacing: 4) {
					Image(systemName: "2.circle.fill")
						.imageScale(.large)
						.frame(maxHeight: .infinity)
						.clipped()
					Text("partie 2")
						.font(.caption2)
				}
				.foregroundColor(Color.secondary)
				.frame(maxWidth: .infinity, alignment: .center)
				.clipped()
				VStack(spacing: 4) {
					Image(systemName: "3.circle.fill")
						.imageScale(.large)
						.frame(maxHeight: .infinity)
						.clipped()
					Text("partie 3")
						.font(.caption2)
				}
				.foregroundColor(Color.secondary)
				.frame(maxWidth: .infinity, alignment: .center)
				.clipped()
			}
			.padding(.bottom, 34)
			.padding(.horizontal, 15)
			.padding(.top, 5)
			.background(VStack(spacing: 0) {
				Divider()
				VisualEffectView(style: .systemMaterial)
			}, alignment: .center)
			.frame(maxHeight: 84)
			.clipped()
		}
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct VisualEffectView: UIViewRepresentable {
    let style: UIBlurEffect.Style
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        return UIVisualEffectView(effect: UIBlurEffect(style: style))
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = UIBlurEffect(style: style)
    }
}